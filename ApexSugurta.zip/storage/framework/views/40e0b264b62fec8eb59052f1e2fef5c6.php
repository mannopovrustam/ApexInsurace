<?php $__env->startSection('content'); ?>

    <div class="container">
        <div class="card">
            <div class="card-header d-flex align-items-end justify-content-between">
                <h2>Users Management</h2>
                <a class="btn btn-success" href="<?php echo e(route('users.create')); ?>"> Create New User </a>
            </div>
            <div class="card-body">

                <?php if($message = Session::get('success')): ?>
                    <div class="alert alert-success">
                        <p><?php echo e($message); ?></p>
                    </div>
                <?php endif; ?>


                <table class="table table-sm table-hover table-bordered table-striped table-nowrap align-middle">
                    <tr>
                        <th>No</th>
                        <th>Name</th>
                        <th>Email</th>
                        <th>Roles</th>
                        <th width="280px">Action</th>
                    </tr>
                    <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e(++$i); ?></td>
                            <td><?php echo e($user->name); ?></td>
                            <td><?php echo e($user->email); ?></td>
                            <td>
                                <?php if(!empty($user->getRoleNames())): ?>
                                    <?php $__currentLoopData = $user->getRoleNames(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $v): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php echo e($v); ?>

                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php endif; ?>
                            </td>
                            <td>
                                <a class="btn btn-info" href="<?php echo e(route('users.show',$user->id)); ?>">Show</a>
                                <a class="btn btn-primary" href="<?php echo e(route('users.edit',$user->id)); ?>">Edit</a>
                                <button type="button" class="btn btn-outline-danger" data-toggle="modal"
                                        data-target="#deleteUser<?php echo e($user->id); ?>">Delete
                                </button>
                            </td>
                        </tr>

                        <div class="modal fade" id="deleteUser<?php echo e($user->id); ?>" tabindex="1" style="z-index: 1050"
                             role="dialog"
                             aria-labelledby="deleteUser<?php echo e($user->id); ?>" aria-hidden="true">
                            <div class="modal-dialog modal-sm" role="document">
                                <div class="modal-content">
                                    <div class="modal-header">
                                        <h5 class="modal-title" id="deleteUser<?php echo e($user->id); ?>">Are you sure delete user:
                                            <br><b><?php echo e($user->name); ?></b></h5>
                                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                            <span aria-hidden="true">×</span>
                                        </button>
                                    </div>
                                    <div class="modal-footer">
                                        <?php echo Form::open(['method' => 'DELETE','route' => ['users.destroy', $user->id],'style'=>'display:inline']); ?>

                                        <?php echo Form::submit('Delete', ['class' => 'btn btn-outline-danger']); ?>

                                        <?php echo Form::close(); ?>

                                        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close
                                        </button>
                                    </div>
                                </div>
                            </div>
                        </div>

                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </table>


                <?php echo $data->render(); ?>

            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\ApexSugurta\resources\views/users/index.blade.php ENDPATH**/ ?>