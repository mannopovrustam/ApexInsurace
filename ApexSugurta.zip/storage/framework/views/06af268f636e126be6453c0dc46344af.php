<?php $__env->startSection('style'); ?>
    <link href="<?php echo e(asset('assets/libs/select2/css/select2.min.css')); ?>" rel="stylesheet" type="text/css"/>
    <link href="https://cdnjs.cloudflare.com/ajax/libs/jquery-confirm/3.3.2/jquery-confirm.min.css" rel="stylesheet"
          type="text/css"/>

    <style>
        .input-group-text:hover {
            color: #fff;
            background: red;
            transition: all 0.3s;
        }
    </style>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>
    <script src="<?php echo e(asset('assets/libs/select2/js/select2.min.js')); ?>"></script>
    <script src="http://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-confirm/3.3.2/jquery-confirm.min.js"></script>

    <script>
        var counter;

        $(document).ready(function () {
            counter = <?php echo e(count(explode(',', $data->client->phone))); ?>;
            $("#add-input").click(function () {
                counter++;
                var inputId = "input_" + counter;
                var inputHtml = '<div class="input-group mt-1" id="group_' + inputId + '"><div class="input-group-text" style="cursor: pointer" onclick="removeInput(\'' + inputId + '\')"><i class="fa fa-minus"></i></div><input id="phone-' + inputId + '" name="phone[]" type="text" class="form-control" placeholder="XXYYYYYYY" required></div>';
                $("#input-container").append(inputHtml);
            });

            var cntr = 0;
            $("#add-file").click(function () {
                cntr++;
                var inputId = "input_" + cntr;
                var inputHtml = '<div class="d-flex mt-1" id="file_' + inputId + '"><select name="file_name[]" id="file_name" class="form-select" required><option value="Суғурта шартномаси">Суғурта шартномаси</option><option value="Кредит шартномаси">Кредит шартномаси</option><option value="Паспорт нусхаси">Паспорт нусхаси</option><option value="Тўлов топширқномаси">Тўлов топширқномаси</option><option value="Бошқа ҳужжатлар">Бошқа ҳужжатлар</option></select><input type="file" name="file[]" id="file" class="form-control ml-2" required><button type="button" class="btn btn-danger ml-2" onclick="removeFile(\'' + inputId + '\')"><i class="fa fa-minus"></i></button></div>';
                $("#input-container-file").append(inputHtml);
            });

            $("#cp_table").load('<?php echo e(asset('contracts/payments/'.$data->id)); ?>')
            $('#contractPay').on('click', function () {
                var formData = $('#contract_payments').serialize();

                $.ajax({
                    url: "<?php echo e(asset('contracts/payment')); ?>",
                    type: "POST",
                    data: formData,
                    success: function (data) {
                        $.alert({
                            title: data.message,
                            content: data.content,
                            type: 'green',
                            buttons: {ok: {text: 'OK', btnClass: 'btn-green'}}
                        });
                        $("#cp_table").load('<?php echo e(asset('contracts/payments/'.$data->id)); ?>');

                        $('#payment_amount').val();
                        $('#payment_date').val();
                    },
                    error: function (data) {
                        console.log(data.responseJSON)
                        $.alert({
                            title: data.responseJSON.message,
                            content: JSON.stringify(data.responseJSON.errors),
                            type: 'red',
                            buttons: {ok: {text: 'OK', btnClass: 'btn-red'}}
                        });
                    }
                })
            });

            $('#taxExpense').on('click', function () {
                var formData = $('#tax_expense').serialize();

                $.ajax({
                    url: "<?php echo e(asset('contracts/expense')); ?>",
                    type: "POST",
                    data: formData,
                    success: function (data) {
                        $.alert({
                            title: data.message,
                            content: data.content,
                            type: 'green',
                            buttons: {ok: {text: 'OK', btnClass: 'btn-green'}}
                        });
                    },
                    error: function (data) {
                        console.log(data.responseJSON.errors)
                        $.alert({
                            title: data.responseJSON.message,
                            content: JSON.stringify(data.responseJSON.errors),
                            type: 'red',
                            buttons: {ok: {text: 'OK', btnClass: 'btn-red'}}
                        });
                    }
                })
            });

            <?php if($data->client->district_id): ?>
                $.ajax({
                    url: '<?php echo e(asset('data/districts')); ?>',
                    data: {region_id: $('#region_id').val(), selected: '<?php echo e($data->client->district_id); ?>'},
                    success: function (data) {
                        $("#district_id").html(data)
                    }
                })
            <?php endif; ?>
            $('#region_id').on('change', function () {
                $.ajax({
                    url: '<?php echo e(asset('data/districts')); ?>',
                    data: {region_id: $('#region_id').val(), selected: '<?php echo e($data->client->district_id); ?>'},
                    success: function (data) {
                        $("#district_id").html(data)
                    }
                })
            })



            <?php if(session()->has('message')): ?>
                notify("<?php echo e(session()->get('message')); ?>", "success");
            <?php endif; ?>

            <?php if(session()->has('errors')): ?>
                <?php $__currentLoopData = json_decode(session()->get('errors')); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    notify("<?php echo e($value[0]); ?>", "error");
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php endif; ?>
        });

        $('#passport').keyup(function() {
            var inputValue = $(this).val();
            var latinRegex = /^[a-zA-Z0-9\s]*$/; // Regular expression to allow only Latin characters and spaces

            if (!latinRegex.test(inputValue)) {
                $(this).val(function(_, val) {
                    return val.replace(/[^a-zA-Z0-9\s]/g, ''); // Remove non-Latin characters from the input value
                });
            }
        });

        $('#pinfl').keyup(function() {
            var inputValue = $(this).val();
            var latinRegex = /^[0-9\s]*$/; // Regular expression to allow only Latin characters and spaces

            if (!latinRegex.test(inputValue)) {
                $(this).val(function(_, val) {
                    return val.replace(/[^0-9\s]/g, ''); // Remove non-Latin characters from the input value
                });
            }
        });

        function changePayment(id, amount, date) {
            $('#payment_id').val(id);
            $('#payment_amount').val(amount);
            $('#payment_date').val(date);
        }

        function removeInput(id) {
            $('#group_' + id).remove();
        }

        function removeFile(id) {
            $('#file_' + id).remove();
        }

        function findGuest() {
            var passport = $('#passport').val();
            var pinfl = $('#pinfl').val();

            $.ajax({
                url: "/contracts/find-guest",
                data: {
                    passport: passport,
                    pinfl: pinfl,
                },
                success: function (data) {
                    var guestname = ''
                    if (data.status == 'success') {
                        guestname = data.data.fullname;
                        $('#fullname').val(data.data.fullname);
                        $('#address').val(data.data.address);
                        $('#region_id').val(data.data.region_id)
                        $('#type').val(data.data.type)
                        $('#dtb').val(data.data.dtb)
                        $('#passport').val(data.data.passport)
                        $('#pinfl').val(data.data.pinfl)

                        $.ajax({
                            url: '<?php echo e(asset('data/districts')); ?>',
                            data: {region_id: $('#region_id').val(), selected: data.data.district_id},
                            success: function (data) {
                                $("#district_id").html(data)
                            }
                        });

                        var string = data.data.phone;
                        var items = string.split(",");
                        $('.input-group').remove();

                        $.each(items, function (index, item) {
                            counter++;
                            var inputId = "input_" + counter;
                            var inputHtml = '<div class="input-group" id="group_' + inputId + '"><div class="input-group-text" style="cursor: pointer" onclick="removeInput(\'' + inputId + '\')"><i class="fa fa-minus"></i></div><input id="phone-' + inputId + '" name="phone[]" type="text" class="form-control" placeholder="XXYYYYYYY" value="' + item + '" required></div>';
                            $("#input-container").append(inputHtml);
                        });
                    }
                    $.alert({
                        title: data.message,
                        content: guestname,
                        type: data.color,
                        buttons: {ok: {text: 'OK', btnClass: 'btn-' + data.color}}
                    });
                }
            })
        }
    </script>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>

    <div class="container">
        <div class="row">
            <div class="col-md-12">


                <div class="card" id="user">
                    <div class="card-header d-flex justify-content-between">
                        <p>Регистрация</p>
                        <?php if($data->id): ?> <a href="<?php echo e(asset('contracts').'/'.$data->id); ?>"><?php echo e($data->number .'-'. $data->name); ?></a> <?php endif; ?>
                        <a href="<?php echo e(asset('contracts')); ?>" class="btn btn-primary"><i class="uil-left-arrow-from-left"></i> Ортга</a>
                    </div>
                    <div class="card-body">
                        <form action="/contracts" method="post" enctype="multipart/form-data">
                            <?php echo csrf_field(); ?>
                            <input type="hidden" name="data_id" value="<?php echo e($data->id); ?>">
                            <div class="row">

                                <div class="col-md-3">
                                    <div class="form-group">
                                        <label for="passport">Паспорт маълумотлари</label>
                                        <input type="text" class="form-control" id="passport"
                                               value="<?php echo e(isset($data->id) ? $data->client->passport : old('passport')); ?>"
                                               name="passport" placeholder="ZZ0011223">
                                    </div>
                                </div>
                                <div class="col-md-3">
                                    <div class="form-group">
                                        <label for="pinfl">ПИНФЛ</label>
                                        <input type="text" class="form-control" id="pinfl" minlength="14" maxlength="14"
                                               value="<?php echo e(isset($data->id) ? $data->client->pinfl : old('pinfl')); ?>"
                                               name="pinfl" placeholder="01234567891234">
                                    </div>
                                </div>
                                <div class="col-md-3">
                                    <div class="form-group">
                                        <label for="dtb">Туғилган санаси</label>
                                        <input type="date" class="form-control" id="dtb" value="<?php echo e(isset($data->id) ? $data->client->dtb : old('dtb')); ?>"
                                               name="dtb" placeholder="00.00.0000" required>
                                    </div>
                                </div>
                                <div class="col-md-3">
                                    <div class="form-group">
                                        <label>&nbsp;</label><br>
                                        <button type="button" class="btn btn-primary" onclick="findGuest()"><i
                                                class="fa fa-search"></i> Қидириш
                                        </button>
                                    </div>
                                </div>

                                <div class="col-md-3">
                                    <div class="form-group">
                                        <label for="number">Иш туркуми</label>
                                        <select class="form-select select2" name="category_id" required>
                                            <option value="">*** Иш туркуми ***</option>
                                            <?php $__currentLoopData = \App\Models\Category::with('categories')->where('category_id', null)->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <?php if(count($category->categories)>0): ?>
                                                    <optgroup label="<?php echo e($category->name); ?>">
                                                        <?php $__currentLoopData = $category->categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <option value="<?php echo e($c->id); ?>" <?php if($c->id == $data->category_id): echo 'selected'; endif; ?>><?php echo e($c->name); ?></option>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    </optgroup>
                                                <?php else: ?>
                                                    <option
                                                        value="<?php echo e($category->id); ?>" <?php if($category->id == $data->category_id): echo 'selected'; endif; ?>>
                                                        <?php echo e($category->name); ?>

                                                    </option>
                                                <?php endif; ?>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                    </div>
                                </div>
                                <div class="col-md-3">
                                    <div class="form-group">
                                        <label for="brand">Шартнома рақами</label>
                                        <input type="text" class="form-control" id="number" value="<?php echo e(isset($data->id) ? $data->number : old('number')); ?>"
                                               name="number" placeholder="Шартнома рақами">
                                    </div>
                                </div>
                                <div class="col-md-3">
                                    <div class="form-group">
                                        <label for="name">Шартнома номи</label>
                                        <input type="text" class="form-control" id="name" value="<?php echo e(isset($data->id) ? $data->name : old('name')); ?>"
                                               name="name" placeholder="Шартнома номи">
                                    </div>
                                </div>
                                <div class="col-md-3">
                                    <div class="form-group">
                                        <label for="date">Шартнома санаси</label>
                                        <input type="date" class="form-control " id="date" value="<?php echo e(isset($data->id) ? $data->date : old('date')); ?>"
                                               name="date" placeholder="Шартнома санаси">
                                    </div>
                                </div>
                                <div class="col-md-12">
                                    <div class="form-group">
                                        <label for="type">Қарздор ФИШ</label>
                                        <input type="text" class="form-control" id="fullname"
                                               value="<?php echo e(isset($data->id) ? $data->client->fullname : old('fullname')); ?>"
                                               name="fullname" placeholder="ФИШ">
                                    </div>
                                </div>


                                <div class="col-md-4">
                                    <div class="form-group">
                                        <label for="address">Вилоят</label>
                                        <select class="form-select" name="region_id" id="region_id" required>
                                            <option value="">*** Вилоят танланг ***</option>
                                            <?php $__currentLoopData = \DB::table('regions')->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rgn): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option
                                                    value="<?php echo e($rgn->id); ?>" <?php if($data->client->region_id == $rgn->id): echo 'selected'; endif; ?>><?php echo e($rgn->name); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                    </div>
                                </div>
                                <div class="col-md-4">
                                    <div class="form-group">
                                        <label for="address">Туман</label>
                                        <select class="form-select" name="district_id" id="district_id">
                                            <option value="">*** Туман танланг ***</option>
                                        </select>
                                    </div>
                                </div>
                                <div class="col-md-4">
                                    <div class="form-group">
                                        <label for="address">Манзили</label>
                                        <input type="text" class="form-control" id="address"
                                               value="<?php echo e(isset($data->id) ? $data->client->address : old('address')); ?>"
                                               name="address" placeholder="Манзили">
                                    </div>
                                </div>

                                <div class="col-md-4">
                                    <div class="form-group">
                                        <label for="phone">Қарздорнинг телефон рақами </label> <span
                                            class="btn-sm btn-primary" style="padding:1px 6px 3px 5px; cursor: pointer"
                                            id="add-input">+</span>
                                        <div id="input-container">
                                            <?php $__empty_1 = true; $__currentLoopData = explode(',', $data->client->phone); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $phone): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                                <div class="input-group mt-1" id="group_<?php echo e($key+1); ?>">
                                                    <div class="input-group-text" style="cursor: pointer"
                                                         onclick="removeInput('<?php echo e($key+1); ?>')"><i class="fa fa-minus"></i>
                                                    </div>
                                                    <input id="phone-<?php echo e($key+1); ?>" type="text" name="phone[]"
                                                           class="form-control" value="<?php echo e($phone); ?>"
                                                           placeholder="XXYYYYYYY" required>
                                                </div>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                </div>


                                <div class="col-md-4">
                                    <div class="form-group">
                                        <label for="type">Қарздор шакли</label>
                                        <select class="form-select" name="type" id="type" required>
                                            <option value="">*** Шахс танланг ***</option>
                                            <option value="0" <?php if($data->client->type == 0): echo 'selected'; endif; ?>>Жисмоний шахс</option>
                                            <option value="1" <?php if($data->client->type == 1): echo 'selected'; endif; ?>>Юридик шахс</option>
                                        </select>
                                    </div>
                                </div>
                                <div class="col-md-4">
                                    <div class="form-group">
                                        <label for="date_payment">Суғурта товони тўланган сана</label>
                                        <input type="date" class="form-control inputmaskDate" id="date_payment"
                                               value="<?php echo e(isset($data->id) ? $data->date_payment : old('date_payment')); ?>"
                                               name="date_payment" placeholder="Суғурта товони тўланган сана">
                                    </div>
                                </div>
                                <div class="col-md-4">
                                    <div class="form-group">
                                        <label for="amount">Суғурта товони суммаси</label>
                                        <input type="number" step="0.01" class="form-control" id="amount"
                                               value="<?php echo e(isset($data->id) ? $data->amount : old('amount')); ?>"
                                               name="amount" placeholder="0.00">
                                    </div>
                                </div>

                                <div class="col-md-4">
                                    <div class="form-group">
                                        <label for="sts">Шартнома ҳолати</label>
                                        <select class="form-select" name="status" id="sts" required>
                                            <?php $__currentLoopData = \App\Models\Client::STATUS_NAME; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $status): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($key); ?>" <?php if($data->status == $key): echo 'selected'; endif; ?>><?php echo e($status); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                    </div>
                                </div>
                                <div class="form-group mt-3">
                                    <button type="submit" class="btn btn-success">Saqlash</button>
                                </div>
                            </div>

                        </form>

                    </div>

                </div>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\ApexSugurta\resources\views/view/contract/create.blade.php ENDPATH**/ ?>