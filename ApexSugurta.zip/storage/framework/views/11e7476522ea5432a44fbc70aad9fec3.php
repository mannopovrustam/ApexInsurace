<?php $__env->startSection('style'); ?>
    <link rel="stylesheet" href="https://cdn.datatables.net/1.10.25/css/jquery.dataTables.min.css">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/jquery-confirm/3.3.2/jquery-confirm.min.css" rel="stylesheet"
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>

    <script src="http://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
    <script src="<?php echo e(asset('/assets/libs/datatables.net/js/jquery.dataTables.min.js')); ?>"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-confirm/3.3.2/jquery-confirm.min.js"></script>

    <script>
        var table = null;

        $(document).ready(function() {
            table = $('#region-table').DataTable();

            $('#region-table tbody').on('dblclick', 'tr', function() {
                updateSelected($(this).data('id'), $(this).data('name'), $(this).data('type'), $(this).data('region'));
            });

        });
        $(document).ready(function() {
            table = $('#district-table').DataTable();

            $('#district-table tbody').on('dblclick', 'tr', function() {
                updateSelected($(this).data('id'), $(this).data('name'), $(this).data('type'), $(this).data('region'));
            });

        });


        function getSelected(){
            var total = table.rows('.selected').count();

            if (total == 0) {
                $.alert({
                    icon: 'fa fa-info',
                    closeIcon: true,
                    type: 'red',
                    title: '&nbsp;Не выбран гость!',
                    content: '<br>Сначало выберите гостя щелкнув левой кнопкой мыши по строке!',
                    columnClass: 'small',
                });
                return false;
            }
            return true;
        }

        function updateSelected(id, name, type, region) {
            var content = '', url = '', data = [];
            if(type) {
                content = '<form id="myForm"><div class="form-group"><input type="hidden" id="id" class="form-control" value="'+id+'"></div><div class="form-group"><label for="name">Name:</label><input type="text" id="name" class="form-control" value="'+name+'"></div></form>';
                url = '/dic/region';
            }else{
                content = '<form id="myForm">' +
                    '<div class="form-group"><input type="hidden" id="id" class="form-control" value="'+id+'"></div>' +
                    '<div class="form-group">' +
                    '<select name="region_id" id="region_id" class="form-control">' +
                    <?php $__currentLoopData = $regions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $region): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        '<option value="<?php echo e($region->id); ?>" ' + ((region == <?php echo e($region->id); ?>) ? 'selected':'') +'><?php echo e($region->name); ?></option>' +
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    '</select>'+
                    '</div>' +
                    '<div class="form-group"><label for="name">Name:</label><input type="text" id="name" class="form-control" value="'+name+'"></div>' +
                    '</form>';
                url = '/dic/district';
            }
            $.confirm({
                title: 'Ўзгартириш',
                content: content,
                buttons: {
                    confirm: {
                        text: 'Сақлаш',
                        action: function () {
                            var id = $('#id').val();
                            var name = $('#name').val();
                            var region_id = $('#region_id').val();
                            if (name == '') {
                                $.alert({
                                    icon: 'fa fa-info',
                                    closeIcon: true,
                                    type: 'red',
                                    title: '&nbsp;Ўзгартириш',
                                    content: '<br>Маълумотлар тўлиқ киритилмаган!',
                                    columnClass: 'small',
                                });
                                return false;
                            }
                            if(type == 1) {
                                data = {data_id: id,name: name,_token: '<?php echo e(csrf_token()); ?>'};
                            }else{
                                data = {data_id:id, region_id:region_id, name:name, _token:'<?php echo e(csrf_token()); ?>'};
                            }

                            $.ajax({
                                url: url,
                                type: 'POST',
                                data: data,
                                success: function (data) {
                                    if (data.success) {
                                        $.alert({
                                            icon: 'fa fa-info',
                                            closeIcon: true,
                                            type: 'green',
                                            title: '&nbsp;Ўзгартириш',
                                            content: '<br>Маълумотлар муваффақиятли ўзгартирилди!',
                                            columnClass: 'small',
                                        });
                                        location.reload();
                                    } else {
                                        $.alert({
                                            icon: 'fa fa-info',
                                            closeIcon: true,
                                            type: 'red',
                                            title: '&nbsp;Ўзгартириш',
                                            content: '<br>Маълумотлар ўзгартирилмади!',
                                            columnClass: 'small',
                                        });
                                    }
                                }
                            })
                        }
                    },
                    cancel: {
                        text: 'Бекор қилиш',
                        action: function () {
                            // Handle cancel action
                        }
                    }
                }
            });

        }


        $('#region-table').on('processing.dt', function(e, settings, processing) {
            if (processing)
                $('.ajaxLoading').show();
            else
                $('.ajaxLoading').hide();
        })



    </script>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('content'); ?>

    <div class="container">
        <div class="row">
            <div class="col-md-6">
                <div class="card" id="user">
                    <div class="card-header d-flex justify-content-between">
                        <h5>Вилоятлар</h5>
                    </div>

                    <div class="card-body">
                        <table class="table" id="region-table">
                            <thead>
                            <tr>
                                <th>Номи</th>
                            </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $regions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $region): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr data-id="<?php echo e($region->id); ?>" data-name="<?php echo e($region->name); ?>" data-type="1" role="row">
                                        <td><?php echo e($region->name); ?></td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
            <div class="col-md-6">
                <div class="card" id="user">
                    <div class="card-header d-flex justify-content-between">
                        <h5>Туманлар</h5>
                    </div>

                    <div class="card-body">
                        <table class="table" id="district-table">
                            <thead>
                            <tr>
                                <th>Вилоят</th>
                                <th>Туман</th>
                            </tr>
                            </thead>
                            <tbody>
                            <?php $__currentLoopData = $districts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $district): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr data-id="<?php echo e($district->id); ?>" data-name="<?php echo e($district->name); ?>" data-type="0" data-region="<?php echo e($district->region_id); ?>" role="row">
                                    <td><?php echo e($district->region_name); ?></td>
                                    <td><?php echo e($district->name); ?></td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\ApexSugurta\resources\views/view/dic/regions.blade.php ENDPATH**/ ?>