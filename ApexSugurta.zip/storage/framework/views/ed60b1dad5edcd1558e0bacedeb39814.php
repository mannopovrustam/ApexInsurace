<footer class="footer">
    <div class="container-fluid">
        <div class="row">
            <div class="col-sm-6">
                <script>document.write(new Date().getFullYear())</script> © mannopovr.
            </div>
            <div class="col-sm-6">
                <div class="text-sm-end d-none d-sm-block">
                    <a href="#" target="_blank" class="text-reset">mannopovr</a>
                </div>
            </div>
        </div>
    </div>
</footer>
<?php /**PATH C:\wamp64\www\ApexSugurta\resources\views/components/footer.blade.php ENDPATH**/ ?>