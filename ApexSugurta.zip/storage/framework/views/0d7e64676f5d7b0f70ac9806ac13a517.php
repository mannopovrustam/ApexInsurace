<?php $__env->startSection('content'); ?>

    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <div class="card" id="user">
                    <div class="card-header d-flex justify-content-between">
                        <div>
                            Суғурта шартномаси <b><?php echo e($data->number); ?></b>
                        </div>
                        <div class="d-flex">
                            <a href="/contracts/create" class="btn btn-primary mr-3">Янги шартнома</a>
                            <a href="/contracts/<?php echo e($data->id); ?>/edit" class="btn btn-warning">Ўзгартириш</a>
                        </div>
                    </div>

                    <div class="card-body">
                        <table class="table">
                            <tbody>
                            <tr>
                                <th>Иш туркуми</th>
                                <td><?php echo e($data->category->name); ?></td>
                            </tr>
                            <tr>
                                <th>Суғурта шартномаси</th>
                                <td><?php echo e($data->number); ?></td>
                            </tr>
                            <tr>
                                <th>Қарздор ФИШ</th>
                                <td><?php echo e($data->client->fullname); ?></td>
                            </tr>
                            <tr>
                                <th>Паспорт маълумотлари</th>
                                <td><?php echo e($data->client->passport); ?></td>
                            </tr>
                            <tr>
                                <th>Қарздорнинг телефон рақами</th>
                                <td><?php echo e($data->client->phone); ?></td>
                            </tr>
                            <tr>
                                <th>Манзили</th>
                                <td><?php echo e($data->client->address); ?></td>
                            </tr>
                            <tr>
                                <th>Туғилган санаси</th>
                                <td><?php echo e(\Carbon\Carbon::parse($data->client->dtb)->format('d.m.Y')); ?></td>
                            </tr>
                            <tr>
                                <th>Қарздор шакли</th>
                                <td><?php echo e($data->client->type); ?></td>
                            </tr>
                            <tr>
                                <th>Суғурта товони тўланган сана</th>
                                <td><?php echo e(\Carbon\Carbon::parse($data->date)->format('d.m.Y')); ?></td>
                            </tr>
                            <tr>
                                <th>Суғурта товони суммаси</th>
                                <td><?php echo e($data->amount); ?></td>
                            </tr>
                            <tr>
                                <th>Ҳолати</th>
                                <td><?php echo e($data->status); ?></td>
                            </tr>
                            <tr>
                                <th>Изоҳ</th>
                                <td><?php echo e($data->note); ?></td>
                            </tr>
                            <tr>
                                <th>Яратилган сана</th>
                                <td><?php echo e(\Carbon\Carbon::parse($data->created_at)->format('d.m.Y')); ?></td>
                            </tr>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\ApexSugurta\resources\views/view/petition/show.blade.php ENDPATH**/ ?>